package com.aishang.shopback_1908;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Shopback1908Application {

    public static void main(String[] args) {
        SpringApplication.run(Shopback1908Application.class, args);
    }

}
