package com.aishang.shopback_1908.dao;

import com.aishang.shopback_1908.po.Categorysecond;
import tk.mybatis.MyMapper;

public interface CategorysecondMapper extends MyMapper<Categorysecond> {
}