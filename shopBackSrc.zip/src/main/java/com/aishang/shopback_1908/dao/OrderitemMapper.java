package com.aishang.shopback_1908.dao;

import com.aishang.shopback_1908.po.Orderitem;
import tk.mybatis.MyMapper;

public interface OrderitemMapper extends MyMapper<Orderitem> {
}