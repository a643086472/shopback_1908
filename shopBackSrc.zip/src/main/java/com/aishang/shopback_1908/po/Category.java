package com.aishang.shopback_1908.po;

import javax.persistence.*;

@Table(name = "shop..category")
public class Category {
    @Id
    private Integer cid;

    private String cname;

    /**
     * @return cid
     */
    public Integer getCid() {
        return cid;
    }

    /**
     * @param cid
     */
    public void setCid(Integer cid) {
        this.cid = cid;
    }

    /**
     * @return cname
     */
    public String getCname() {
        return cname;
    }

    /**
     * @param cname
     */
    public void setCname(String cname) {
        this.cname = cname;
    }
}