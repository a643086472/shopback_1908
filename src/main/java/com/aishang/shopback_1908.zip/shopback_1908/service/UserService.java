package com.aishang.shopback_1908.service;

import com.aishang.shopback_1908.po.User;

import javax.annotation.Resource;
import java.util.List;

public interface UserService {

    List<User> getAll();
}
