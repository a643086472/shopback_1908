package com.aishang.shopback_1908.dao;

import com.aishang.shopback_1908.po.TbUsers;
import tk.mybatis.MyMapper;

public interface TbUsersMapper extends MyMapper<TbUsers> {
}